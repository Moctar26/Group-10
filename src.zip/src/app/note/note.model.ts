export class Note {
  constructor(
      public title?: string,
      public content?: string,
      public date?: Date,
  ) {
  }
}
