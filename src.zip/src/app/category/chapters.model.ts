export class Chapters{
  constructor(
    public id?: string,
    public title?: string,
    public content?: string
  ){}
}
